package come.telegram;

public class Keys {
    public static final String Bot_name = "weathertelegram01bot";
    public static final String Telegram_Key = "1564520709:AAG0LDuNrvBLQYngWnj5AV9gje-1yNAfDYU";

}
